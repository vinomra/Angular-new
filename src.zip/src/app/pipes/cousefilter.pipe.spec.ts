import { CousefilterPipe } from './cousefilter.pipe';

describe('CousefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CousefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
