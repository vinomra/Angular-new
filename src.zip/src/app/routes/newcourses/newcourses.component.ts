import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcourses',
  templateUrl: './newcourses.component.html',
  styleUrls: ['./newcourses.component.css']
})
export class NewcoursesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
