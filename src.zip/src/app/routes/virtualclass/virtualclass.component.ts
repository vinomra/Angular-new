import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-virtualclass',
  templateUrl: './virtualclass.component.html',
  styleUrls: ['./virtualclass.component.css']
})
export class VirtualclassComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
