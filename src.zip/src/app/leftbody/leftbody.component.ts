import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftbody',
  templateUrl: './leftbody.component.html',
  styleUrls: ['./leftbody.component.css']
})
export class LeftbodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
