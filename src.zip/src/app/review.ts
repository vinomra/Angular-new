export interface review{
    name:string;
    reviewdate:string;
    course:string;
    message:string;
    email:string;
}